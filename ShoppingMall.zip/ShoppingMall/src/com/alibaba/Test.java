package com.alibaba;

import java.io.File;

import org.springframework.stereotype.Component;

@Component
public class Test {

	
	public  void  fileTest() {
		
	}
	
	public static void main(String[] args) {
		System.out.print(new File("D:\\Eclipse_Workspace\\ShoppingMall\\WebContent\\img\\nova 2\\曜石黑.png"));
	}

}
