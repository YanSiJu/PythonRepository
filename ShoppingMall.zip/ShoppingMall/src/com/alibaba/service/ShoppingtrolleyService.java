package com.alibaba.service;

import org.springframework.stereotype.Service;

import com.alibaba.entity.GoodsPrice;

@Service
public interface ShoppingtrolleyService {

	// 修改购物车内商品数量
	void modifyGoodsQuantity(GoodsPrice price, int currentQuantity, int shoppingtrolleyId);

	// 删除购物车内商品
	void deleteGoods(int goodsId, int shoppingtrolleyId);

	// 添加商品到购物车
	void addGoods(double price, int goodsId, int quantity, int shoppingtrolleyId);

}
