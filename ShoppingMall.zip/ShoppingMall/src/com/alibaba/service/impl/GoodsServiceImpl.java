package com.alibaba.service.impl;

import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.alibaba.entity.Goods;
import com.alibaba.entity.GoodsImg;
import com.alibaba.entity.GoodsInfo;
import com.alibaba.entity.GoodsPrice;
import com.alibaba.mapper.GoodsImgMapper;
import com.alibaba.mapper.GoodsMapper;
import com.alibaba.mapper.GoodsPriceMapper;
import com.alibaba.service.GoodsService;

@Service
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	private GoodsPriceMapper priceMapper;
	@Autowired
	private GoodsImgMapper imgMapper;
	@Autowired
	private GoodsMapper goodsMapper;

	@Override
	public GoodsInfo displayGoods() {

		Set<GoodsPrice> prices = priceMapper.queryGoodsPrice();
		Set<GoodsImg> img = imgMapper.queryGoodsImg();
		List<Goods> goods = goodsMapper.queryGoods();
		GoodsInfo goodsInfo = new GoodsInfo(prices, img, goods);

		return goodsInfo;
		// System.out.println("\n" + " goods:");
		// for (Goods g : goods) {
		// System.out.print(g.getId() + " ");
		// }
		//
		// System.out.println("\n" + " prices:");
		// for (GoodsPrice p : prices) {
		// System.out.print(p.getGoodsId() + " ");
		// }
		//
		// System.out.println("\n" + " img:");
		// for (GoodsImg i : img) {
		// System.out.print(i.getGoodsId()+ " ");
		// }

		// System.out.println("prices:" + prices + "\nimg:" + img + " \ngoods:" +
		// goods);

	}

}
