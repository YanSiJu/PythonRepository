package com.alibaba.service.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.alibaba.entity.Goods;
import com.alibaba.entity.GoodsImg;
import com.alibaba.entity.GoodsInfo;
import com.alibaba.entity.GoodsPrice;
import com.alibaba.entity.SortedGoodsInfo;
import com.alibaba.mapper.GoodsImgMapper;
import com.alibaba.mapper.GoodsMapper;
import com.alibaba.mapper.GoodsPriceMapper;
import com.alibaba.service.GoodsService;

@Service
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	private GoodsPriceMapper priceMapper;
	@Autowired
	private GoodsImgMapper imgMapper;
	@Autowired
	private GoodsMapper goodsMapper;

	@Override
	public GoodsInfo displayGoods() {

		Set<GoodsPrice> prices = priceMapper.queryGoodsPrice();
		Set<GoodsImg> img = imgMapper.queryGoodsImg();
		List<Goods> goods = goodsMapper.queryGoods();
		GoodsInfo goodsInfo = new GoodsInfo(prices, img, goods);
		return goodsInfo;

		// System.out.println("\n" + " goods:");
		// for (Goods g : goods) {
		// System.out.print(g.getId() + " ");
		// }
		//
		// System.out.println("\n" + " prices:");
		// for (GoodsPrice p : prices) {
		// System.out.print(p.getGoodsId() + " ");
		// }
		//
		// System.out.println("\n" + " img:");
		// for (GoodsImg i : img) {
		// System.out.print(i.getGoodsId()+ " ");
		// }

		// System.out.println("prices:" + prices + "\nimg:" + img + " \ngoods:" +
		// goods);

	}

	@Override
	public SortedGoodsInfo orderByPrice() {
		// 获取商品信息
		GoodsInfo info = displayGoods();
		Set<GoodsPrice> prices = info.getPrices();
		List<Goods> goods = info.getGoods();
		Set<GoodsImg> image = info.getImg();
		// 将Set转为List，用于排序
		List<GoodsPrice> prcs = new LinkedList<GoodsPrice>(prices);
		// 按照price排序
		Collections.sort(prcs, new Comparator<GoodsPrice>() {

			@Override
			public int compare(GoodsPrice o1, GoodsPrice o2) {
				if (o1.getPrice() > o2.getPrice()) {
					return 1;
				} else if (o1.getPrice() == o2.getPrice()) {
					return 0;
				}
				return -1;
			}

		});
		return moveElementsToNewCollection(goods, image, prcs);

	}

	@Override
	public SortedGoodsInfo orderBySalesVolume() {
		// 获取商品信息
		GoodsInfo info = displayGoods();
		Set<GoodsPrice> prices = info.getPrices();
		List<Goods> goods = info.getGoods();
		Set<GoodsImg> image = info.getImg();
		// 将Set转为List，用于排序
		List<GoodsPrice> prcs = new LinkedList<GoodsPrice>(prices);
		// 按照SlaesVolume排序
		Collections.sort(prcs, new Comparator<GoodsPrice>() {

			@Override
			public int compare(GoodsPrice o1, GoodsPrice o2) {
				if (o1.getSlaesVolume() > o2.getSlaesVolume()) {
					return 1;
				} else if (o1.getSlaesVolume() == o2.getSlaesVolume()) {
					return 0;
				}
				return -1;
			}

		});
		return moveElementsToNewCollection(goods, image, prcs);

	}

	SortedGoodsInfo moveElementsToNewCollection(List<Goods> goods, Set<GoodsImg> image, List<GoodsPrice> prcs) {// 根据prcs对goods集合和image集合进行调整，使其goodsId的顺序一致
		Goods[] goodsArray = new Goods[goods.size()];
		GoodsImg[] imgArray = new GoodsImg[image.size()];
		for (GoodsPrice p : prcs) {
			int goodsIndex = 0;
			int imgIndex = 0;
			int id = p.getGoodsId();
			// 将goods中的元素转到goodsArray中
			for (Goods g : goods) {
				if (g.getId() == id) {
					goodsArray[goodsIndex++] = g;
				}
			}
			// 将image中的元素转到imgArray中
			for (GoodsImg i : image) {
				if (i.getGoodsId() == id) {
					imgArray[imgIndex++] = i;
				}
			}

		}
		image = null;// Let GC do it's work
		goods = null;
		List<Goods> g = Arrays.asList(goodsArray);
		List<GoodsImg> img = Arrays.asList(imgArray);
		return new SortedGoodsInfo(g, img, prcs);
	}

	@Override
	public GoodsInfo fuzzyQueryGoods(String param) {
		// 查询商品的价格以及图片地址
		Set<GoodsPrice> prices = priceMapper.queryGoodsPrice();
		Set<GoodsImg> img = imgMapper.queryGoodsImg();
		// 根据字符串模糊查询商品
		List<Goods> goods = goodsMapper.fuzzyQueryGoods(param);
		// 保留在goods中存在的商品
		retain(prices, img, goods);
		GoodsInfo goodsInfo = new GoodsInfo(prices, img, goods);
		return goodsInfo;
	}

	private void retain(Set<GoodsPrice> prices, Set<GoodsImg> img, List<Goods> goods) {

		for (GoodsPrice p : prices) {
			int id = p.getGoodsId();
			boolean priceFlag = false;
			for (Goods g : goods) {
				if (g.getId() == id) {
					priceFlag = true;
					break;
				}
			}
			if (!priceFlag) {
				prices.remove(p);
			}
		}

		for (GoodsImg i : img) {
			int id = i.getGoodsId();
			boolean flag = false;
			for (Goods g : goods) {
				if (g.getId() == id) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				img.remove(i);
			}
		}
		
	}

}
