package com.alibaba.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.alibaba.entity.GoodsPrice;
import com.alibaba.entity.goodsInShoppingtrolley;
import com.alibaba.mapper.ShoppingTrolleyMapper;
import com.alibaba.service.ShoppingtrolleyService;

@Service
public class ShoppingtrolleyServiceImpl implements ShoppingtrolleyService {

	@Autowired
	private ShoppingTrolleyMapper mapper;

	@Override
	public void addGoods(double price, int goodsId, int quantity, int shoppingtrolleyId) {
		mapper.insertGoods(new goodsInShoppingtrolley(shoppingtrolleyId, goodsId, quantity, quantity * price));

	}

	@Override
	public void modifyGoodsQuantity(GoodsPrice price, int currentQuantity, int shoppingtrolleyId) {
		mapper.updateGoods(new goodsInShoppingtrolley(shoppingtrolleyId, price.getGoodsId(), currentQuantity,
				currentQuantity * price.getPrice()));
	}

	@Override
	public void deleteGoods(int goodsId, int shoppingtrolleyId) {
		mapper.deleteGoods(goodsId, shoppingtrolleyId);
	}

}
