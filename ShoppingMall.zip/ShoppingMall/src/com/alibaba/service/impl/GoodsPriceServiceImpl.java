package com.alibaba.service.impl;

import org.springframework.stereotype.Service;
import com.alibaba.service.GoodsPriceService;

@Service
public class GoodsPriceServiceImpl implements GoodsPriceService {

}
