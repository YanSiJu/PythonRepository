package com.alibaba.service;

import org.springframework.stereotype.Service;

import com.alibaba.entity.GoodsInfo;
import com.alibaba.entity.SortedGoodsInfo;

@Service
public interface GoodsService {

	GoodsInfo displayGoods();

	SortedGoodsInfo orderByPrice();

	SortedGoodsInfo orderBySalesVolume();

	GoodsInfo fuzzyQueryGoods(String param);

}
