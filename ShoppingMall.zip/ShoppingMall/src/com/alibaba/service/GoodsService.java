package com.alibaba.service;

import org.springframework.stereotype.Service;

import com.alibaba.entity.GoodsInfo;

@Service
public interface GoodsService {

	GoodsInfo displayGoods();

}
