package com.alibaba.mapper;

import java.util.Set;
import org.springframework.stereotype.Repository;
import com.alibaba.entity.GoodsPrice;

@Repository
public interface GoodsPriceMapper {
	
	
	public Set<GoodsPrice> queryGoodsPrice();

}
