package com.alibaba.mapper;

import org.springframework.stereotype.Repository;
import com.alibaba.entity.Order;

@Repository
public interface OrderMapper {

	void insertOrder(Order o);

}
