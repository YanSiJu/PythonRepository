package com.alibaba.mapper;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import com.alibaba.entity.ShoppingTrolley;
import com.alibaba.entity.goodsInShoppingtrolley;

@Repository
public interface ShoppingTrolleyMapper {

	void createShoppingTrolley(ShoppingTrolley trolley);

	ShoppingTrolley queryShoppingTrolley(int userId);

	void insertGoods(goodsInShoppingtrolley trolley);

	void updateGoods(goodsInShoppingtrolley trolley);

	void deleteGoods(@Param("goodsId") int goodsId, @Param("shoppingtrolleyId") int shoppingtrolleyId);
}
