package com.alibaba.mapper;


import java.util.Set;
import org.springframework.stereotype.Repository;
import com.alibaba.entity.GoodsImg;

@Repository
public interface GoodsImgMapper {
	
	public Set<GoodsImg> queryGoodsImg();
	

}
