package com.alibaba.entity;

//保存购物车内的商品信息
public class goodsInShoppingtrolley {

	private int shoppingtrolleyId;
	private int goodsId;
	// 数量
	private int quantity;

	public int getShoppingtrolleyId() {
		return shoppingtrolleyId;
	}

	@Override
	public String toString() {
		return "goodsInShoppingtrolley [shoppingtrolleyId=" + shoppingtrolleyId + ", goodsId=" + goodsId + ", quantity="
				+ quantity + ", amount=" + amount + "]";
	}

	public goodsInShoppingtrolley(int shoppingtrolleyId, int goodsId, int quantity, double amount) {
		super();
		this.shoppingtrolleyId = shoppingtrolleyId;
		this.goodsId = goodsId;
		this.quantity = quantity;
		this.amount = amount;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(amount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + goodsId;
		result = prime * result + quantity;
		result = prime * result + shoppingtrolleyId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		goodsInShoppingtrolley other = (goodsInShoppingtrolley) obj;
		if (Double.doubleToLongBits(amount) != Double.doubleToLongBits(other.amount))
			return false;
		if (goodsId != other.goodsId)
			return false;
		if (quantity != other.quantity)
			return false;
		if (shoppingtrolleyId != other.shoppingtrolleyId)
			return false;
		return true;
	}

	public void setShoppingtrolleyId(int shoppingtrolleyId) {
		this.shoppingtrolleyId = shoppingtrolleyId;
	}

	public int getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	// 金额
	private double amount;

}
