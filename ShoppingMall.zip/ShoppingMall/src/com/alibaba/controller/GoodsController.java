package com.alibaba.controller;

import java.util.LinkedList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.alibaba.entity.GoodsInfo;
import com.alibaba.entity.GoodsPrice;
import com.alibaba.entity.SortedGoodsInfo;
import com.alibaba.service.impl.GoodsServiceImpl;

@Controller
@RequestMapping("goods")
public class GoodsController {

	@Autowired
	private GoodsServiceImpl service;

	@RequestMapping("displayGoods")
	public String displayGoods(HttpServletRequest request) {
		GoodsInfo info = service.displayGoods();
		HttpSession session = request.getSession();
		// List list = new ArrayList(new HashSet());
		List<GoodsPrice> prices = new LinkedList<GoodsPrice>(info.getPrices());
		session.setAttribute("prices", prices);
		session.setAttribute("img", info.getImg());
		session.setAttribute("goods", info.getGoods());
		return "goods";
	}

	@RequestMapping("displayGoodsByPrices")
	public String displayGoodsByPrices(HttpServletRequest request) {
		SortedGoodsInfo info = service.orderByPrice();
		HttpSession session = request.getSession();
		saveInfoToSession(session, info);
		return "goods";
	}

	@RequestMapping("displayGoodsBySalesVolume")
	public String displayGoodsBySalesVolume(HttpServletRequest request) {
		SortedGoodsInfo info = service.orderBySalesVolume();
		HttpSession session = request.getSession();
		saveInfoToSession(session, info);
		return "goods";
	}

	private void saveInfoToSession(HttpSession session, SortedGoodsInfo info) {
		session.setAttribute("prices", info.getPrices());
		session.setAttribute("img", info.getImg());
		session.setAttribute("goods", info.getG());
	}
}
