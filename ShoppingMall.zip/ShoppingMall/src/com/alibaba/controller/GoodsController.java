package com.alibaba.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.alibaba.entity.GoodsInfo;
import com.alibaba.entity.GoodsPrice;
import com.alibaba.service.impl.GoodsServiceImpl;

@Controller
@RequestMapping("goods")
public class GoodsController {

	@Autowired
	private GoodsServiceImpl service;

	@RequestMapping("displayGoods")
	public String displayGoods(HttpServletRequest request) {
		GoodsInfo info = service.displayGoods();
		HttpSession session = request.getSession();
		// List list = new ArrayList(new HashSet());
		List<GoodsPrice> prices = new ArrayList<GoodsPrice>(info.getPrices());
		session.setAttribute("prices", prices);
		session.setAttribute("img", info.getImg());
		session.setAttribute("goods", info.getGoods());
		return "goods";
	}

}
