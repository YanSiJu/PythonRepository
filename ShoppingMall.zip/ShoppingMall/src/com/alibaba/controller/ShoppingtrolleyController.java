package com.alibaba.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.service.impl.ShoppingtrolleyServiceImpl;

@Controller
@RequestMapping("Shoppingtrolley")
public class ShoppingtrolleyController {

	@Autowired
	private ShoppingtrolleyServiceImpl service;

	@RequestMapping("addGoods")
	@ResponseBody
	public Map<String, String> addGoods(@RequestBody String data, HttpServletRequest request) {
		HttpSession session = request.getSession();
		JSONObject jsonObj;
		Map<String, String> map = new HashMap<>();
		try {
			jsonObj = new JSONObject(data);
			double price = Double.valueOf(jsonObj.get("price").toString());
			int goodsId = Integer.valueOf(jsonObj.get("goodsId").toString());
			int quantity = Integer.valueOf(jsonObj.get("quantity").toString());
			int shoppingtrolleyId = (Integer) session.getAttribute("shoppingtrolleyId");
			service.addGoods(price, goodsId, quantity, shoppingtrolleyId);
			map.put("msg", "OK");
		} catch (JSONException e) {
			e.printStackTrace();
			map.put("msg", "error");
		}
		return map;
	}

	@RequestMapping("deleteGoods")
	@ResponseBody
	public Map<String, String> deleteGoods(@RequestBody String data, HttpServletRequest request) {
		HttpSession session = request.getSession();
		JSONObject jsonObj;
		Map<String, String> map = new HashMap<>();
		try {
			jsonObj = new JSONObject(data);
			int goodsId = Integer.valueOf(jsonObj.get("goodsId").toString());
			int shoppingtrolleyId = (Integer) session.getAttribute("shoppingtrolleyId");
			service.deleteGoods(goodsId, shoppingtrolleyId);
			map.put("msg", "OK");
		} catch (JSONException e) {
			e.printStackTrace();
			map.put("msg", "error");
		}
		return map;
	}

}
