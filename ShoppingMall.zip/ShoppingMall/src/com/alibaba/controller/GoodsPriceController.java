package com.alibaba.controller;

public class GoodsPriceController {

}
