package com.alibaba.controller;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.entity.User;
import com.alibaba.service.impl.UserServiceImpl;

@Controller
@RequestMapping("User")
public class UserController {

	@Autowired
	private UserServiceImpl service;

	@RequestMapping("register")
	public String register(@RequestParam("address") String address, @RequestParam("userName") String userName,
			@RequestParam("password") String password, @RequestParam("tel") String tel, @RequestParam("id") int id,
			@RequestParam("name") String name, HttpServletRequest request) {
		User user = new User(name, address, userName, password, tel, id);
		service.register(user);
		request.setAttribute("userName", userName);
		return "registerSuccess";
	}

	@RequestMapping("regist")
	public String register() {
//		return "sendCode";
		return "register";
	}

	@RequestMapping("loginSkip")
	public String login() {
		return "login";
	}

	@RequestMapping("sendCode")
	@ResponseBody
	public Map<String, String> sendValidateCode(@RequestBody String mobile) {
		Map<String, String> result = new HashMap<String, String>();
		result.put("code", "code");
		
		System.out.println(result);
		return result;
	}

	@RequestMapping("validateUserName")
	@ResponseBody
	public Map<String, String> ifUserNameDuplicate(@RequestBody String name) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			JSONObject jsonobj = new JSONObject(name);
			System.out.println(jsonobj.get("name").toString());
			if (service.validateUserName(jsonobj.get("name").toString())) {
				result.put("msg", "该用户名已被注册");
			} else {
				result.put("msg", "OK");
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		System.out.println("ifUserNameDuplicate\n name---->" + name + "\nresult:" + result);
		return result;
	}

	@RequestMapping("login")
	public String login(@RequestParam("userName") String name, @RequestParam("password") String pwd,
			HttpServletRequest request) {

		User user = service.login(name, pwd);
		if (user != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			System.out.println("----->登录成功!!");
			return "index";
		}
		request.setAttribute("errorMsg", "帐号或密码错误，请重新输入");
		request.setAttribute("userName", name);
		request.setAttribute("pwd", pwd);
		return "login";
	}

}
