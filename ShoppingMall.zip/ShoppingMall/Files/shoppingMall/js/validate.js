$(document).ready(function() {
	$("#sendmsg").click(function() {
		var tel = $("#mobile").val(); //获取手机号码输入框值  
		var reg = /^1[0-9]{10}$/; //   /^1[3|4|5|8][0-9]\d{4,8}$/
		if(!reg.test(tel)) { //校验手机号码格式  
			$("#mobile_error").text("请先输入您的正确手机号！");
			document.regitform.focus();
			return false;
		} else {
			$("#mobile_error").text("");
			return true;
		}
		var data;
		//jquery post方法同步提交  
		//（提交地址；   data：返回值）  
		$.ajax({
			url: '#',
			type: 'POST',
			data: JSON.stringify(data),
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			success: function(data) {
				if(data != null && typeof(data) != "undefined") {
					var msg = data.msg; //返回值为json格式  
					if(msg != null && typeof(msg) != "undefined" && msg == "SUCCESS") {
						get_code_time(); //发送成功则调用get_code_time（）函数  
					} else {
						alert("短信验证码发送失败！请重新获取。");
					}
				}
			},
			error: function(msg) {
				
			}
		});

		function get_code_time() {
			var wait = 120;
			if(wait == 0) {
				$("#updateverify").removeAttr("disabled"); //移除获取验证码按钮的disabled属性  
				$("#updateverify").val("获取验证码");
				wait = 120;
			} else {
				$("#updateverify").attr("disabled", true); //设置获取验证码按钮为不可触发  
				$("#updateverify").val("剩(" + wait + ")秒");
				wait--;
				setTimeout("get_code_time()", 1000);
			}
		}
	})
})